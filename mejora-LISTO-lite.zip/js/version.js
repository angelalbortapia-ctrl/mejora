/** Versión única de assets — bump aquí y ejecuta: npm run sync-version */
export const ASSET_VERSION = 194

/** Sufijo para URLs estáticas (CSS en index.html, service-worker) */
export const ASSET_QUERY = `?v=${ASSET_VERSION}`
