import { enrichMission } from '/js/coaching.js'
import { appStore, STORE_PREFIX, setStorePersistHook } from '/js/core/store.js'

export const PREFIX = STORE_PREFIX
export { appStore, setStorePersistHook } from '/js/core/store.js'

if (typeof window !== 'undefined') {
  setStorePersistHook(() => {
    import('/js/cloud-sync.js').then(m => m.scheduleCloudPush?.()).catch(() => {})
  })
}
export const SKILLS = {
  mental: { name: 'Neurociencia', icon: '🧠', color: '#00d4ff' },
  mindfulness: { name: 'Calma', icon: '🧘', color: '#a78bfa' },
  discipline: { name: 'Disciplina', icon: '⚡', color: '#ff8c69' },
  wisdom: { name: 'Sabiduría', icon: '📖', color: '#00f5d4' },
}

export const DIFFICULTIES = {
  facil: { label: 'Fácil', icon: '🌱', mult: 1, xp: 15 },
  medio: { label: 'Medio', icon: '⚡', mult: 1.5, xp: 30 },
  dificil: { label: 'Difícil', icon: '🔥', mult: 2, xp: 55 },
  experto: { label: 'Experto', icon: '💎', mult: 3, xp: 100 },
}

export const RANKS = [
  { min: 1, title: 'Novato', icon: '🌱' },
  { min: 5, title: 'Aprendiz', icon: '📘' },
  { min: 10, title: 'Practicante', icon: '⚡' },
  { min: 20, title: 'Experto', icon: '🏆' },
  { min: 35, title: 'Maestro', icon: '👑' },
  { min: 50, title: 'Leyenda', icon: '💎' },
]

export function getItem(key, fallback = null) {
  return appStore.get(key, fallback)
}

export function setItem(key, value) {
  return appStore.set(key, value)
}

/** Borra todo el progreso local (FORGE desde cero). */
export function resetAllData() {
  const keys = []
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i)
    if (key?.startsWith(PREFIX)) keys.push(key)
  }
  keys.forEach(k => localStorage.removeItem(k))
}

export function toDateStr(date = new Date()) {
  const d = date instanceof Date ? date : new Date(date)
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

export function getToday() {
  return toDateStr(new Date())
}

export function esc(str) {
  return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;')
}

export function getProgress() {
  return appStore.getProgress()
}

export function saveProgress(p) {
  return appStore.saveProgress(p)
}

export function xpForLevel(level) {
  return level * level * 80
}

export function getLevel(xp) {
  let level = 1
  while (xp >= xpForLevel(level + 1)) level++
  return level
}

export function getLevelInfo(xp) {
  const level = getLevel(xp)
  const floor = xpForLevel(level)
  const ceiling = xpForLevel(level + 1)
  const percent = Math.min(100, ((xp - floor) / (ceiling - floor)) * 100)
  return { level, xp, floor, ceiling, percent: Math.round(percent) }
}

export function getTotalLevel() {
  const p = getProgress()
  const levels = Object.values(p.xp).map(x => getLevel(x))
  return Math.round(levels.reduce((a, b) => a + b, 0) / levels.length) || 1
}

export function getRank(level = getTotalLevel()) {
  let rank = RANKS[0]
  for (const r of RANKS) if (level >= r.min) rank = r
  return rank
}

export function addXp(skill, baseXp, source = '') {
  const p = getProgress()
  const before = getLevel(p.xp[skill] || 0)
  p.xp[skill] = (p.xp[skill] || 0) + baseXp
  saveProgress(p)
  const after = getLevel(p.xp[skill])
  checkAchievements(source)
  syncGoals()
  return { xp: baseXp, skill, levelUp: after > before, newLevel: after }
}

export function recordActivity(type) {
  const today = getToday()
  const log = getItem('activityLog', {})
  if (!log[today]) log[today] = []
  if (!log[today].includes(type)) log[today].push(type)
  setItem('activityLog', log)

  const p = getProgress()
  const week = getWeekNumber()
  if (p.weekly.week !== week) p.weekly = { week, done: 0, target: 5, rewarded: false }
  let activeDays = 0
  for (let i = 0; i < 7; i++) {
    const d = new Date()
    d.setDate(d.getDate() - i)
    const dateStr = toDateStr(d)
    if (log[dateStr]?.length) activeDays++
  }
  p.weekly.done = activeDays
  if (p.weekly.done >= p.weekly.target && !p.weekly.rewarded) {
    p.weekly.rewarded = true
    addXp('discipline', 200, 'weekly')
  }
  saveProgress(p)
}

function getShieldMonthKey() {
  const d = new Date()
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`
}

export function hasStreakShieldUnlocked() {
  return getTotalLevel() >= 15
}

export function getStreakShieldStatus() {
  const p = getProgress()
  const month = getShieldMonthKey()
  const used = p.streakShield?.month === month && p.streakShield?.used
  return {
    unlocked: hasStreakShieldUnlocked(),
    available: hasStreakShieldUnlocked() && !used,
    used,
    month,
    savedDate: p.streakShield?.savedDate || null,
  }
}

export function getStreak() {
  const log = getItem('activityLog', {})
  const p = getProgress()
  const monthKey = getShieldMonthKey()
  const shieldAlreadyUsed = p.streakShield?.month === monthKey && p.streakShield?.used
  let canSkip = hasStreakShieldUnlocked() && !shieldAlreadyUsed

  let streak = 0
  const d = new Date()
  const today = getToday()
  if (!log[today]?.length) d.setDate(d.getDate() - 1)

  for (let i = 0; i < 365; i++) {
    const dateStr = toDateStr(d)
    if (log[dateStr]?.length) {
      streak++
      d.setDate(d.getDate() - 1)
    } else if (canSkip) {
      canSkip = false
      if (!shieldAlreadyUsed) {
        p.streakShield = { month: monthKey, used: true, savedDate: dateStr }
        saveProgress(p)
      }
      d.setDate(d.getDate() - 1)
    } else break
  }
  return streak
}

export const MOODS = [
  { id: 1, emoji: '😔', label: 'Bajo' },
  { id: 2, emoji: '😐', label: 'Neutral' },
  { id: 3, emoji: '🙂', label: 'Bien' },
  { id: 4, emoji: '😊', label: 'Genial' },
]

export function getMood(date = getToday()) {
  const v = getItem(`mood_${date}`, null)
  return v ? MOODS.find(m => m.id === v) || null : null
}

export function setMood(moodId, date = getToday()) {
  setItem(`mood_${date}`, moodId)
  recordActivity('mood')
  return MOODS.find(m => m.id === moodId)
}

export function getMoodWeek() {
  const labels = ['D', 'L', 'M', 'X', 'J', 'V', 'S']
  return Array.from({ length: 7 }, (_, i) => {
    const d = new Date()
    d.setDate(d.getDate() - (6 - i))
    const dateStr = toDateStr(d)
    const mood = getMood(dateStr)
    return { label: labels[d.getDay()], date: dateStr, mood, isToday: i === 6 }
  })
}

export function getMoodInsight() {
  const week = getMoodWeek().filter(d => d.mood)
  if (week.length < 3) return 'Registra tu ánimo 3 días para ver patrones en tu semana.'
  const avg = week.reduce((s, d) => s + d.mood.id, 0) / week.length
  const lows = week.filter(d => d.mood.id <= 2).length
  const highs = week.filter(d => d.mood.id >= 4).length
  if (avg >= 3.5) {
    return highs >= 3
      ? 'Semana luminosa. Canaliza esa energía en una meta concreta antes de que se disperse en mil tareas.'
      : 'Ánimo positivo sostenido. Buen momento para subir dificultad en laboratorio o reflexión experta.'
  }
  if (avg >= 2.5) {
    return lows >= 2
      ? 'Ánimo mixto: días duros alternados con buenos. Las rutinas cortas en días bajos son las que salvan la racha.'
      : 'Ritmo estable. Una reflexión de nivel medio puede revelar qué necesitas ajustar sin drama.'
  }
  if (lows >= 4) return 'Semana pesada. No exijas perfección — una rutina express y 5 min de calma son victoria suficiente.'
  return 'Semana exigente. Prioriza sueño, calma y hábitos mínimos. Volver mañana es el único plan que importa.'
}

export function getStats() {
  return appStore.getStats()
}

export function updateStats(updates) {
  return appStore.updateStats(updates)
}

export function getSettings() {
  return appStore.getSettings()
}

export function needsOnboarding() {
  return !getSettings().onboardingComplete
}

/** Usuarios con progreso previo sin flag de onboarding — migración única */
export function migrateOnboardingFlag() {
  const s = getSettings()
  if (s.onboardingComplete) return
  const stats = getStats()
  if (stats.routinesCompleted > 0 || stats.brainSessions > 0 || stats.habitsCompleted > 0) {
    s.onboardingComplete = true
    saveSettings(s)
  }
}

export function saveSettings(s) {
  if (s.darkMode) s.darkMode = false
  appStore.saveSettings(s)
  document.documentElement.classList.remove('dark')
  document.documentElement.classList.toggle('reduce-motion', !!s.reducedMotion)
}

/** Migración — Notion Light: ignora darkMode y temas legacy en localStorage */
export function migrateNotionLight() {
  const s = getSettings()
  const needsThemeReset = s.theme && s.theme !== 'default'
  if (s.darkMode || needsThemeReset) {
    s.darkMode = false
    if (needsThemeReset) s.theme = 'default'
    appStore.saveSettings(s)
  }
  const root = document.documentElement
  root.dataset.notionLight = '1'
  root.classList.remove('dark')
  root.removeAttribute('data-theme')
  root.style.colorScheme = 'light'
  document.body?.classList.remove('theme-rpg')
}

function parseBgLuminance(bg) {
  const m = String(bg || '').match(/[\d.]+/g)
  if (!m || m.length < 3) return 255
  return (+m[0] + +m[1] + +m[2]) / 3
}

/** Si el body sigue oscuro (caché legacy), inyecta notion-light-force.css */
export function enforceNotionLightRuntime(assetVersion = 194) {
  const body = document.body
  if (!body) return
  const lum = parseBgLuminance(getComputedStyle(body).backgroundColor)
  if (lum >= 140) return
  if (!document.getElementById('notion-light-force-link')) {
    const link = document.createElement('link')
    link.id = 'notion-light-force-link'
    link.rel = 'stylesheet'
    link.href = `/css/notion-light-force.css?v=${assetVersion}`
    document.head.appendChild(link)
  }
  const root = document.documentElement
  root.dataset.notionLight = '1'
  root.classList.remove('dark')
  root.removeAttribute('data-theme')
  body.classList.remove('theme-rpg')
  body.style.setProperty('background-color', '#ffffff', 'important')
  body.style.setProperty('color', '#37352f', 'important')
}

const DEFAULT_HABITS = [
  { id: 'water', name: 'Hidratación', icon: '💧', category: 'salud', difficulty: 1, xp: 15, type: 'counter', target: 8, unit: 'vasos' },
  { id: 'read', name: 'Lectura', icon: '📚', category: 'mente', difficulty: 2, xp: 25, type: 'counter', target: 20, unit: 'min' },
  { id: 'exercise', name: 'Ejercicio físico', icon: '🏃', category: 'salud', difficulty: 3, xp: 35, type: 'check', target: 1, unit: 'sesión' },
  { id: 'learn', name: 'Aprender algo nuevo', icon: '🎓', category: 'mente', difficulty: 3, xp: 40, type: 'check', target: 1, unit: 'vez' },
]

export function getHabits() {
  const habits = getItem('habits', DEFAULT_HABITS)
  return habits.map(h => ({
    ...h,
    category: h.category || 'productividad',
    difficulty: h.difficulty || 2,
    xp: h.xp || 20,
    type: h.type || 'check',
    target: h.target || 1,
    unit: h.unit || 'vez',
  }))
}

export function getHabitCounts(date = getToday()) {
  return getItem(`habit_counts_${date}`, {})
}

export function getHabitCount(habitId, date = getToday()) {
  return getHabitCounts(date)[habitId] || 0
}

export function isHabitComplete(habit, date = getToday()) {
  if (habit.type === 'counter') return getHabitCount(habit.id, date) >= habit.target
  return getItem(`habits_${date}`, []).includes(habit.id)
}

export function getCompletedHabitsCount(date = getToday()) {
  return getHabits().filter(h => isHabitComplete(h, date)).length
}

export function getHabitProgress(habitId) {
  const p = getProgress()
  if (!p.habitData[habitId]) p.habitData[habitId] = { xp: 0, streak: 0, bestStreak: 0, total: 0 }
  return p.habitData[habitId]
}

function markHabitComplete(habit) {
  const today = getToday()
  const completed = getItem(`habits_${today}`, [])
  if (completed.includes(habit.id)) return null

  setItem(`habits_${today}`, [...completed, habit.id])
  recordActivity('habit')

  const p = getProgress()
  const hd = getHabitProgress(habit.id)
  const yesterday = new Date()
  yesterday.setDate(yesterday.getDate() - 1)
  const yStr = toDateStr(yesterday)
  const doneYesterday = isHabitComplete(habit, yStr)
  hd.streak = doneYesterday ? hd.streak + 1 : 1
  hd.bestStreak = Math.max(hd.bestStreak, hd.streak)
  hd.total++
  const bonus = Math.floor(habit.difficulty * 10 * (1 + hd.streak * 0.1))
  hd.xp += bonus
  p.habitData[habit.id] = hd
  saveProgress(p)

  updateStats({ habitsCompleted: getStats().habitsCompleted + 1 })
  checkAchievements('habit')
  syncGoals()
  import('/js/product-analytics.js').then(m => {
    m.trackProductEvent(m.EVENTS.HABIT_COMPLETE, { habitId: habit.id })
  }).catch(() => {})
  return { success: true, xp: habit.xp + bonus, name: habit.name, completed: true }
}

export function incrementHabit(habit) {
  const today = getToday()
  if (habit.type === 'check') return markHabitComplete(habit)

  const counts = getHabitCounts(today)
  const current = Math.min((counts[habit.id] || 0) + 1, habit.target + 5)
  counts[habit.id] = current
  setItem(`habit_counts_${today}`, counts)

  const completed = getItem(`habits_${today}`, [])
  if (current >= habit.target && !completed.includes(habit.id)) {
    return markHabitComplete(habit)
  }
  return { success: true, partial: true, count: current, target: habit.target, name: habit.name }
}

export function decrementHabit(habit) {
  const today = getToday()
  const counts = getHabitCounts(today)
  const current = Math.max(0, (counts[habit.id] || 0) - 1)
  counts[habit.id] = current
  setItem(`habit_counts_${today}`, counts)

  if (current < habit.target) {
    const completed = getItem(`habits_${today}`, [])
    if (completed.includes(habit.id)) {
      setItem(`habits_${today}`, completed.filter(id => id !== habit.id))
    }
  }
  return { count: current, target: habit.target }
}

export function completeHabit(habit) {
  return incrementHabit(habit)
}

export function uncompleteHabit(habitId) {
  const today = getToday()
  const completed = getItem(`habits_${today}`, [])
  setItem(`habits_${today}`, completed.filter(id => id !== habitId))
  const counts = getHabitCounts(today)
  delete counts[habitId]
  setItem(`habit_counts_${today}`, counts)
}

export function setRecord(game, difficulty, score) {
  const p = getProgress()
  const key = `${game}_${difficulty}`
  const prev = p.records[key] || { best: 0, plays: 0 }
  p.records[key] = { best: Math.max(prev.best, score), plays: prev.plays + 1, last: getToday() }
  saveProgress(p)
}

export function getRecord(game, difficulty) {
  return getProgress().records[`${game}_${difficulty}`] || { best: 0, plays: 0 }
}

const ACHIEVEMENTS = [
  { id: 'first_routine', name: 'Primer paso', desc: 'Completa tu primera rutina', icon: '🌱', check: () => getStats().routinesCompleted >= 1 },
  { id: 'streak_7', name: 'Semana fuerte', desc: 'Racha de 7 días', icon: '🔥', check: () => getStreak() >= 7 },
  { id: 'streak_30', name: 'Imparable', desc: 'Racha de 30 días', icon: '💪', check: () => getStreak() >= 30 },
  { id: 'brain_10', name: 'Cerebro entrenado', desc: '10 sesiones de laboratorio', icon: '🧠', check: () => getStats().brainSessions >= 10 },
  { id: 'meditate_60', name: 'Zen', desc: '60 minutos meditados', icon: '🧘', check: () => getStats().meditationMinutes >= 60 },
  { id: 'habits_50', name: 'Disciplinado', desc: '50 hábitos completados', icon: '✅', check: () => getStats().habitsCompleted >= 50 },
  { id: 'level_10', name: 'Experiencia', desc: 'Nivel total 10', icon: '⭐', check: () => getTotalLevel() >= 10 },
  { id: 'level_25', name: 'Veterano', desc: 'Nivel total 25', icon: '🏆', check: () => getTotalLevel() >= 25 },
  { id: 'expert_win', name: 'Sin miedo', desc: 'Gana un juego en modo Experto', icon: '💎', check: () => Object.keys(getProgress().records).some(k => k.endsWith('_experto') && getProgress().records[k].best > 0) },
  { id: 'daily_all', name: 'Día perfecto', desc: 'Completa tu plan del día', icon: '🎯', check: () => getPlanProgress().allDone },
  { id: 'goal_first', name: 'Con visión', desc: 'Completa tu primera meta', icon: '🎯', check: () => getGoals().some(g => g.completed) },
  { id: 'reflections_20', name: 'Introspectivo', desc: '20 reflexiones en rutina', icon: '📖', check: () => getStats().reflections >= 20 },
  { id: 'challenge_10', name: 'Retador', desc: '10 desafíos completados', icon: '⚔️', check: () => getStats().challengesWon >= 10 },
]

export function checkAchievements(source = '') {
  const p = getProgress()
  const newOnes = []
  for (const a of ACHIEVEMENTS) {
    if (!p.achievements.includes(a.id) && a.check()) {
      p.achievements.push(a.id)
      newOnes.push(a)
    }
  }
  if (newOnes.length) saveProgress(p)
  return newOnes
}

export function getAchievements() {
  return ACHIEVEMENTS.map(a => ({ ...a, unlocked: getProgress().achievements.includes(a.id) }))
}

export function getWeekNumber() {
  const d = new Date()
  const start = new Date(d.getFullYear(), 0, 1)
  return Math.ceil(((d - start) / 86400000 + start.getDay() + 1) / 7)
}

const PLAN_CORE = [
  { id: 'routine', type: 'routine', label: 'Completar rutina diaria', icon: '⚔️', xp: 50, link: '#/rutina' },
  { id: 'habits2', type: 'habits', label: 'Completar 2 hábitos', icon: '✅', xp: 35, target: 2, link: '#/mejora' },
]

const PLAN_ROTATING = [
  { id: 'mental', type: 'brain', label: 'Ejercicio mental', icon: '🧠', xp: 40, link: '#/gimnasia' },
  { id: 'meditate', type: 'meditation', label: 'Sesión de calma', icon: '🧘', xp: 35, link: '#/meditacion' },
  { id: 'focus', type: 'focus', label: 'Bloque de enfoque', icon: '⏱️', xp: 30, link: '#/enfoque' },
  { id: 'habits3', type: 'habits', label: 'Completar 3 hábitos', icon: '✅', xp: 45, target: 3, link: '#/mejora' },
  { id: 'express', type: 'express', label: 'Rutina express', icon: '⚡', xp: 35, link: '#/rutina' },
  { id: 'plan_review', type: 'plan_review', label: 'Revisar tu plan', icon: '📋', xp: 20, link: '#/plan' },
]

function buildDailyTasks(dateStr) {
  const d = new Date(dateStr + 'T12:00:00')
  const day = Math.floor((d - new Date(d.getFullYear(), 0, 0)) / 86400000)
  const hour = new Date().getHours()
  const pool = [...PLAN_ROTATING]
  if (hour < 12) {
    pool.unshift({ id: 'morning', type: 'morning', label: 'Abrir el plan de hoy', icon: '🌅', xp: 15, link: '#/plan' })
  } else if (hour >= 18) {
    pool.unshift({ id: 'evening', type: 'evening', label: 'Calma nocturna', icon: '🌙', xp: 25, link: '#/meditacion' })
  }
  const blocked = hour >= 18 ? new Set(['meditate']) : new Set()
  const pick = []
  for (let i = 0; pick.length < 2 && i < pool.length * 3; i++) {
    const t = pool[(day + i * 3) % pool.length]
    if (blocked.has(t.id)) continue
    if (!pick.find(p => p.id === t.id)) pick.push(t)
  }
  return [...PLAN_CORE, ...pick].map(t => enrichMission({ ...t, done: false }))
}

export function ensureDailyPlan() {
  const p = getProgress()
  const today = getToday()
  if (p.plan?.date === today && p.plan?.version === 3) return p.plan

  p.plan = {
    date: today,
    version: 3,
    tasks: buildDailyTasks(today),
    bonusXp: 80,
    bonusClaimed: false,
  }
  saveProgress(p)
  return p.plan
}

export function getPlanProgress() {
  const plan = ensureDailyPlan()
  const done = plan.tasks.filter(t => t.done).length
  const total = plan.tasks.length
  return { done, total, percent: Math.round((done / total) * 100), allDone: done === total }
}

export function checkPlanTask(type) {
  const p = getProgress()
  const plan = ensureDailyPlan()
  const today = getToday()
  let awarded = []

  for (const task of plan.tasks) {
    if (task.done) continue
    let complete = false
    if (task.type === type) complete = true
    if (task.type === 'habits' && type === 'habit' && getCompletedHabitsCount(today) >= (task.target || 2)) complete = true
    if (task.type === 'express' && type === 'express') complete = true

    if (complete) {
      task.done = true
      const result = addXp('discipline', task.xp, 'plan')
      awarded.push({ task, result })
    }
  }

  const allDone = plan.tasks.every(t => t.done)
  if (allDone && !plan.bonusClaimed) {
    plan.bonusClaimed = true
    const bonus = addXp('discipline', plan.bonusXp, 'plan_bonus')
    awarded.push({ bonus: true, result: bonus })
  }

  p.plan = plan
  saveProgress(p)
  checkAchievements('daily')
  return awarded
}

export const GOAL_TEMPLATES = [
  { title: 'Racha de 30 días', metric: 'streak', target: 30, skill: 'discipline', icon: '🔥', days: 30, pitch: 'La identidad de alguien que vuelve, día tras día.' },
  { title: '30 rutinas completadas', metric: 'routines', target: 30, skill: 'discipline', icon: '⚔️', days: 30, pitch: '30 mañanas donde elegiste entrenarte antes del ruido.' },
  { title: '100 ejercicios mentales', metric: 'brain', target: 100, skill: 'mental', icon: '🧠', days: 90, pitch: 'Cerebro más ágil, atención más estable — medible en semanas.' },
  { title: '60 minutos meditados', metric: 'meditation', target: 60, skill: 'mindfulness', icon: '🧘', days: 30, pitch: 'Una hora de calma acumulada cambia cómo reaccionas bajo presión.' },
  { title: '20 rutinas con reflexión', metric: 'reflections', target: 20, skill: 'wisdom', icon: '📝', days: 45, pitch: 'Veinte mañanas donde paraste a pensar antes de actuar.' },
  { title: '100 hábitos completados', metric: 'habits', target: 100, skill: 'discipline', icon: '✅', days: 60, pitch: 'Sistema sobre motivación — cien pruebas de que funciona.' },
  { title: '14 días de racha', metric: 'streak', target: 14, skill: 'discipline', icon: '🔥', days: 21, pitch: 'Dos semanas seguidas — el umbral donde el hábito empieza a sentirse normal.' },
  { title: '200 minutos de calma', metric: 'meditation', target: 200, skill: 'mindfulness', icon: '🌊', days: 60, pitch: 'Tres horas de práctica acumulada — tu sistema nervioso lo nota.' },
  { title: '50 lecciones de escuela', metric: 'brain', target: 50, skill: 'mental', icon: '🏛️', days: 120, pitch: 'Medio currículo dominado — cerebro con mapa, no solo hacks.' },
  { title: '30 reflexiones escritas', metric: 'reflections', target: 30, skill: 'wisdom', icon: '📔', days: 45, pitch: 'Un mes de pensar en papel — claridad que no da el scroll.' },
  { title: '21 días sin romper plan', metric: 'routines', target: 21, skill: 'discipline', icon: '⚔️', days: 30, pitch: 'Tres semanas donde el plan del día no fue opcional.' },
]

export function getGoals() {
  return getItem('goals', [])
}

export function addGoal(template) {
  const goals = getGoals()
  if (goals.filter(g => g.active).length >= 3) return false
  const start = getToday()
  const end = new Date()
  end.setDate(end.getDate() + (template.days || 30))
  goals.push({
    id: 'goal_' + Date.now(),
    title: template.title,
    icon: template.icon,
    metric: template.metric,
    target: template.target,
    skill: template.skill,
    startDate: start,
    endDate: toDateStr(end),
    active: true,
    completed: false,
    progress: 0,
    milestonesHit: [],
  })
  setItem('goals', goals)
  return true
}

export function getGoalProgress(goal) {
  const stats = getStats()
  const map = {
    streak: getStreak(),
    routines: stats.routinesCompleted,
    brain: stats.brainSessions,
    meditation: stats.meditationMinutes,
    reflections: stats.reflections,
    habits: stats.habitsCompleted,
  }
  return map[goal.metric] || 0
}

export function syncGoals() {
  const goals = getGoals()
  const today = getToday()
  let changed = false
  const xpRewards = []

  const GOAL_MILESTONES = [25, 50, 75]
  for (const goal of goals) {
    if (!goal.active || goal.completed) continue
    goal.progress = getGoalProgress(goal)
    if (!goal.milestonesHit) goal.milestonesHit = []
    const pct = goal.target ? Math.min(100, Math.round((goal.progress / goal.target) * 100)) : 0
    for (const m of GOAL_MILESTONES) {
      if (pct >= m && !goal.milestonesHit.includes(m)) {
        goal.milestonesHit.push(m)
        xpRewards.push({ skill: goal.skill, xp: Math.floor(m / 2), source: 'goal_milestone' })
        changed = true
      }
    }
    if (goal.progress >= goal.target) {
      goal.completed = true
      goal.active = false
      goal.completedDate = today
      xpRewards.push({ skill: goal.skill, xp: 150, source: 'goal' })
      changed = true
    }
    if (today > goal.endDate && !goal.completed) {
      goal.active = false
      goal.failed = true
      changed = true
    }
  }
  if (changed) setItem('goals', goals)
  for (const { skill, xp, source } of xpRewards) addXp(skill, xp, source)
  return goals
}

export function getHabitWeekChart() {
  const habits = getHabits()
  const labels = ['D', 'L', 'M', 'X', 'J', 'V', 'S']
  const days = []
  for (let i = 6; i >= 0; i--) {
    const d = new Date()
    d.setDate(d.getDate() - i)
    const dateStr = toDateStr(d)
    const count = habits.filter(h => isHabitComplete(h, dateStr)).length
    const total = habits.length
    days.push({
      label: labels[d.getDay()],
      date: dateStr,
      isToday: i === 0,
      count,
      total,
      percent: total ? Math.round((count / total) * 100) : 0,
    })
  }
  const avg = days.length ? Math.round(days.reduce((s, d) => s + d.percent, 0) / days.length) : 0
  const prevAvg = days.length > 1
    ? Math.round(days.slice(0, 3).reduce((s, d) => s + d.percent, 0) / 3)
    : 0
  const recentAvg = days.length > 1
    ? Math.round(days.slice(-3).reduce((s, d) => s + d.percent, 0) / 3)
    : avg
  return { days, habits, avg, trend: recentAvg - prevAvg }
}

export function isRoutineDoneToday() {
  return getItem('activityLog', {})[getToday()]?.includes('routine')
}
